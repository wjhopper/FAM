library(testthat)
library(effsize)

test_check("effsize")
