## ----setup,echo=FALSE,message=FALSE,warning=FALSE------------------------
library(dplyr)
library(ggplot2)
library(reshape2)


## ----neg-exp, echo=FALSE, fig.height = 7, fig.width= 7-------------------
Tmin <- .5
Tmax <- 90
lambdas <- c(3,2,1,.75,.5,.25,.1)
x <- seq(-10,10,by=.2)
y <- sapply(lambdas, function(l) Tmin + (Tmax-Tmin)*exp(-l*abs(x))) %>%
  melt(value.name="RT") %>%
  rename(lambda=Var2) %>%
  mutate(Var1 = rep(x,times= nrow(.)/length(x)),
         lambda = lambdas[lambda]) %>%
  rename(x=Var1)
lambda_plot <- ggplot(y, aes(x=x,y=RT, color = factor(lambda))) +
  geom_line(size=.75) +
  scale_y_continuous(breaks=seq(0,90,by=10)) + 
  scale_color_discrete("Lambda") + 
  scale_x_continuous("Distance to Threshold", breaks=-10:10) + 
  ggtitle("Predicted RT for Different Lambdas")
print(lambda_plot)

