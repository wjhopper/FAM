library(testthat)
library(PCR)

test_check("PCR")
