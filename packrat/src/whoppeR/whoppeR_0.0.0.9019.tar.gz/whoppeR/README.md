# whoppeR

Yet another arbitrary collection of utility functions, but this time, they're in an R package!

Install them with devtools:

```R
install.packages("devtools")
devtools::install_github("wjhopper/whoppeR")
```
