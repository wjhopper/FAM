setGeneric("rococo.test", package="rococo",
           function(x, y, ...) standardGeneric("rococo.test"))

setGeneric("gauss.cor.test", package="rococo",
           function(x, y, ...) standardGeneric("gauss.cor.test"))
